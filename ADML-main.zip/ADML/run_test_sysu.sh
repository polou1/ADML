CUDA_VISIBLE_DEVICES=0 \
 python test_sysu.py -b 64 -a agw -d  sysu_all \
 --iters 200 --momentum 0.1 --eps 0.6 --num-instances 16 \
 --data-dir "Datasets/SYSU-MM01" \
 --logs-dir "training_logs_example/SYSU-MM01" 