CUDA_VISIBLE_DEVICES=0 \
 python test_regdb.py -b 64 -a agw -d  regdb_rgb \
 --iters 100 --momentum 0.1 --eps 0.6 --num-instances 16 \
 --data-dir "Datasets/RegDB/" \
 --logs-dir "training_logs_example/RegDB" 
