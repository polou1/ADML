CUDA_VISIBLE_DEVICES=1 \
python train_sysu.py -mb CMhcl -b 64 -a agw -d  sysu_all \
 --iters 400 --momentum 0.2 --eps 0.6 --num-instances 16 \
 --data-dir "Datasets/SYSU-MM01" \
 --logs-dir "logs/SYSU-MM01" \

