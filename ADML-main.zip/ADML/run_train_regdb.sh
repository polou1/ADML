
for trial in 1
do
CUDA_VISIBLE_DEVICES=0 \
 python train_regdb.py -mb CMhcl -b 64 -a agw -d  regdb_rgb \
 --iters 200 --momentum 0.2 --eps 0.6 --num-instances 16 --trial $trial \
 --data-dir "Datasets/RegDB/" \
 --logs-dir "training_logs_example/RegDB" 
done
echo 'Done'